package com.capstone.pantauharga.repository

import androidx.lifecycle.LiveData
import com.capstone.pantauharga.data.response.HargaNormalResponse
import com.capstone.pantauharga.data.response.InflasiResponse
import com.capstone.pantauharga.data.response.NormalPriceResponse
import com.capstone.pantauharga.data.response.PredictInflationResponse
import com.capstone.pantauharga.data.response.PredictionsItem
import com.capstone.pantauharga.data.response.PricesItem
import com.capstone.pantauharga.data.response.PricesKomoditasItem
import com.capstone.pantauharga.data.response.PricesNormalItem
import com.capstone.pantauharga.data.retrofit.ApiService
import com.capstone.pantauharga.database.AppDatabase
import com.capstone.pantauharga.database.NormalPrice
import com.capstone.pantauharga.database.PredictInflation

class PredictInflationRepository(
    private val apiService: ApiService,
    private val database: AppDatabase
) {
    fun getPredictionById(id: Int): LiveData<PredictInflation?> {
        return database.predictInflationDao().getPredictionById(id)
    }

    fun getPredictionByCommodityAndProvince(commodityName: String, provinceName: String): LiveData<PredictInflation?>{
        return database.predictInflationDao().getPredictionByCommodityAndProvince(commodityName, provinceName)
    }

    fun getAllPrediction(): LiveData<List<PredictInflation>> {
        return database.predictInflationDao().getAllPredictions()
    }

    suspend fun savePrediction(
        komoditasId: String,
        daerahId: String,
        description: String,
        predictions: List<PricesKomoditasItem>,
        commodityName: String,
        provinceName: String
    ) {
        val predictionEntity = PredictInflation(
            komoditasId = komoditasId,
            daerahId = daerahId,
            description = description,
            predictions = predictions,
            commodityName = commodityName,
            provinceName = provinceName
        )
        database.predictInflationDao().insertPrediction(predictionEntity)
    }

    suspend fun deletePrediction(prediction: PredictInflation) {
        database.predictInflationDao().deletePrediction(prediction)
    }

    suspend fun getInflationPredictions(
        daerahId: String,
        komoditasId: String,
        timeRange: Int
    ): InflasiResponse {
        return apiService.getHargaKomoditas(daerahId, komoditasId, timeRange)
    }

    suspend fun getInflationPredictionss(
        commodityId: String,
        provinceId: String,
        timeRange: Int
    ): PredictInflationResponse {
        return apiService.getInflationPredictions(commodityId, provinceId, timeRange)
    }

    fun getAllNormalPrices(): LiveData<List<NormalPrice>> {
        return database.normalPriceDao().getAllNormalPrice()
    }

    fun getNormalPriceByCommodityAndProvince(commodityName: String, provinceName: String): LiveData<NormalPrice?> {
        return database.normalPriceDao().getNormalPriceByCommodityAndProvince(commodityName, provinceName)
    }

    suspend fun saveNormalPrice(
        commodityName: String,
        provinceName: String,
        prices: List<PricesNormalItem>,
        description: String
    ) {
        val normalPriceEntity = NormalPrice(
            commodityName = commodityName,
            provinceName = provinceName,
            normalPrice = prices,
            description = description
        )
        database.normalPriceDao().insertNormalPrice(normalPriceEntity)
    }

    suspend fun deleteNormalPrice(normalPrice: NormalPrice) {
        database.normalPriceDao().deleteNormalPrice(normalPrice)
    }


    suspend fun getNormalPrices(
        commodityId: String,
        provinceId: String
    ): HargaNormalResponse {
        return apiService.getHargaNormal(commodityId, provinceId)
    }


}