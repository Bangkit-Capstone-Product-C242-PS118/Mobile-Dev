package com.capstone.pantauharga.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query


@Dao
interface NormalPriceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNormalPrice(NormalPrice: NormalPrice)

    @Query("SELECT * FROM NormalPrice WHERE id = :id")
    fun getNormalPriceById(id: Int): LiveData<NormalPrice?>

    @Query("SELECT * FROM NormalPrice WHERE commodityName = :commodityName AND provinceName = :provinceName")
    fun getNormalPriceByCommodityAndProvince(commodityName: String, provinceName: String): LiveData<NormalPrice?>

    @Query("SELECT * FROM NormalPrice")
    fun getAllNormalPrice(): LiveData<List<NormalPrice>>

    @Delete
    suspend fun deleteNormalPrice(normalPrice: NormalPrice)

}
