package com.capstone.pantauharga.data.response

data class DataModel(
    val label: String,
    val value: Float
)

