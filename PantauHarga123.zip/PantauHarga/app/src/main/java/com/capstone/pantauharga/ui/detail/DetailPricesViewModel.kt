package com.capstone.pantauharga.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.capstone.pantauharga.data.response.DataItem
import com.capstone.pantauharga.data.response.DataItemDaerah
import com.capstone.pantauharga.data.response.HargaNormalResponse
import com.capstone.pantauharga.data.response.InflasiResponse
import com.capstone.pantauharga.data.response.PredictInflationResponse
import com.capstone.pantauharga.data.response.ListCommoditiesItem
import com.capstone.pantauharga.data.response.ListProvincesItem
import com.capstone.pantauharga.data.response.NormalPriceResponse
import com.capstone.pantauharga.data.response.PredictionsItem
import com.capstone.pantauharga.data.response.PricesItem
import com.capstone.pantauharga.data.response.PricesKomoditasItem
import com.capstone.pantauharga.data.response.PricesNormalItem
import com.capstone.pantauharga.database.NormalPrice
import com.capstone.pantauharga.database.PredictInflation
import com.capstone.pantauharga.repository.PredictInflationRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class DetailPricesViewModel(private val repository: PredictInflationRepository) : ViewModel() {
    private val _location = MutableLiveData<String>()
    val location: LiveData<String> get() = _location

    private val _commodityName = MutableLiveData<String>()
    val commodityName: LiveData<String> get() = _commodityName

    private val _activeFragment = MutableLiveData<String>()
    val activeFragment: LiveData<String> = _activeFragment

    private val _inflationData = MutableLiveData<InflasiResponse>()
    val inflationData: LiveData<InflasiResponse> get() = _inflationData

    private val _normalPrice = MutableLiveData<HargaNormalResponse>()
    val normalPriceData: LiveData<HargaNormalResponse> get() = _normalPrice

    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> get() = _loading

    private val _error = MutableLiveData<Boolean>()
    val error: LiveData<Boolean> get() = _error

    fun getPredictionById(id: Int): LiveData<PredictInflation?> {
        return repository.getPredictionById(id)
    }

    fun getPredictionByCommodityAndProvince(commodityName: String, provinceName: String): LiveData<PredictInflation?> {
        return repository.getPredictionByCommodityAndProvince(commodityName, provinceName)
    }

    fun getAllPrediction(): LiveData<List<PredictInflation>> {
        return repository.getAllPrediction()
    }

    fun savePrediction(komoditasId: String, daerahId: String, description: String, predictions: List<PricesKomoditasItem>, commodityName: String, provinceName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.savePrediction(komoditasId, daerahId, description, predictions, commodityName, provinceName)
        }
    }

    fun deletePrediction(prediction: PredictInflation) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deletePrediction(prediction)
        }
    }

    //normalprice

    fun getNormalPriceByCommodityAndProvince(commodityName: String, provinceName: String): LiveData<NormalPrice?> {
        return repository.getNormalPriceByCommodityAndProvince(commodityName, provinceName)
    }

    fun getAllNormalPrice(): LiveData<List<NormalPrice>> {
        return repository.getAllNormalPrices()
    }

    fun saveNormalPrice(commodityName: String, provinceName: String, normalPrice: List<PricesNormalItem>, description: String,) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveNormalPrice( commodityName, provinceName, normalPrice, description)
        }
    }

    fun deleteNormalPrice(normalPrice: NormalPrice) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteNormalPrice(normalPrice)
        }
    }

    fun setLocation(provinsi: DataItemDaerah) {
        _location.value = provinsi.namaDaerah
    }

    fun setCommodityName(komoditas: DataItem) {
        _commodityName.value = komoditas.namaKomoditas
    }

    fun setActiveFragment(fragmentTag: String) {
        if (_activeFragment.value != fragmentTag) {
            _activeFragment.value = fragmentTag
        }
    }

    fun fetchInflationPrediction(daerahId: String, komoditasId: String, timeRange: Int) {
        _loading.value = true
        viewModelScope.launch {
            try {
                val response = repository.getInflationPredictions(daerahId, komoditasId, timeRange)
                _inflationData.value = response
                _error.value = false
            } catch (e: Exception) {
                _error.value = true
            } finally {
                _loading.value = false
            }
        }
    }

    fun fetchNormalPrices(commodityId: String, provinceId: String) {
        _loading.value = true
        viewModelScope.launch {
            try {
                val response = repository.getNormalPrices(commodityId, provinceId)
                _normalPrice.value = response
                _error.value = false
            } catch (e: Exception) {
                _error.value = true
            } finally {
                _loading.value = false
            }
        }
    }
}