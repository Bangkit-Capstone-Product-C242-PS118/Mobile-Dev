package com.capstone.pantauharga.data.response

import com.google.gson.annotations.SerializedName

data class HargaNormalResponse(

	@field:SerializedName("description")
	val description: String,

	@field:SerializedName("error")
	val error: Boolean,

	@field:SerializedName("message")
	val message: String,

	@field:SerializedName("prices")
	val prices: List<PricesNormalItem>
)

data class PricesNormalItem(

	@field:SerializedName("Harga_Normal")
	val hargaNormal: Int,

	@field:SerializedName("tanggal_harga")
	val tanggalHarga: String
)
